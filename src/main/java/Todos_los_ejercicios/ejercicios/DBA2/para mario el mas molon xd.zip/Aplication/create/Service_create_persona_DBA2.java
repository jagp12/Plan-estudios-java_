package Todos_los_ejercicios.ejercicios.DBA2.Aplication.create;


import Todos_los_ejercicios.ejercicios.DBA2.Domain.Persona_DBA2;

public interface Service_create_persona_DBA2 {

    Persona_DBA2 create_persona(Persona_DBA2 persona_EJTE1) throws Exception;

}
