package Todos_los_ejercicios.ejercicios.DBA2.Insfrastructure.Repository;

public interface PersonaRepositorio_DBA2_Custom {
/*
    Persona_DBA2 addPersona(Persona_DBA2 persona) throws Exception;
    void deletePerson(int i);
    Persona_DBA2 updatePerson(Persona_DBA2 persona, int id);
    Persona_DBA2 findByIdPerson(Persona_DBA2 persona) throws Exception;
*/
}
