package Todos_los_ejercicios.ejercicios.DBA2.Insfrastructure.Controllers.Controllers_persona;

import Todos_los_ejercicios.ejercicios.DBA2.Aplication.find.Service_find_persona_DBA2;
import Todos_los_ejercicios.ejercicios.DBA2.Domain.Persona_DBA2;
import Todos_los_ejercicios.ejercicios.DBA2.Exceptions.Exception_persona_404;
import Todos_los_ejercicios.ejercicios.DBA2.Insfrastructure.Controllers.DTO.PersonaOutputDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RequestMapping(value="DBA2/find")
@RestController
public class Find_controller_persona_DBA2 {

    @Autowired
    Service_find_persona_DBA2 service_find_persona_dba2;

    @GetMapping("/getid/{id}")
    public PersonaOutputDTO get_persona_por_id(@PathVariable String id, @RequestParam(value = "outputType") String ouputType  ) throws Exception_persona_404 {

        return new PersonaOutputDTO(service_find_persona_dba2.find_by_id(id));
        //return servicio_persona.find_by_id(id,ouputType);

    }
/*
    @GetMapping("getuser/{user}")
    public List<PersonaOutputDTO> get_persona_por_nombre(@PathVariable String user, @RequestParam(value = "outputType") String outputType) throws Exception{
        System.out.println("obteniendo por user");
        List<PersonaOutputDTO> lista = service_find_persona_dba2.find_by_user(user,outputType).stream().map((persona -> crear_output_dto(persona))).toList();

        return lista;

    }
*/
    @GetMapping("/all")
    public List<PersonaOutputDTO> get_all_persona(@RequestParam(value = "outputType") String outputType) {

        //devolver lista dto
        System.out.println("lista obtenida");
        return service_find_persona_dba2.find_all(outputType).stream().map(persona -> crear_output_dto(persona)).toList();

    }




    private PersonaOutputDTO crear_output_dto(Persona_DBA2 persona){
        //AsignacionOutputDTO dto = new AsignacionOutputDTO(persona);

        PersonaOutputDTO dto = new PersonaOutputDTO
                (       persona
                        //String.valueOf(persona.getId_persona()),
                        /*
                        persona.getUsuario(),
                        persona.getPassword(),
                        persona.getName(),
                        persona.getSurname(),
                        persona.getCompany_email(),
                        persona.getPersonal_email(),
                        persona.getCity(),
                        persona.getImagen_url(),
                        persona.isActive(),
                        persona.getCreated_date(),
                        persona.getTermination_date()
                    */
                );

        return dto;
    }

}
