package Todos_los_ejercicios.ejercicios.DBA2.Insfrastructure.Repository;

import Todos_los_ejercicios.ejercicios.DBA2.Domain.Persona_DBA2;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;

@Component
public interface PersonaRepositorio_DBA2 extends MongoRepository<Persona_DBA2, Integer> {

}
