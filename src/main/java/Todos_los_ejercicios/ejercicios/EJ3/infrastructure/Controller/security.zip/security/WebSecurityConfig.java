package Todos_los_ejercicios.ejercicios.EJ3.infrastructure.Controller.security;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    public void configure(HttpSecurity http) throws Exception{

        http.csrf().disable()
                .addFilterAfter(new JWTAuthorizationFilter(), UsernamePasswordAuthenticationFilter.class)
                .authorizeRequests()
                .antMatchers("/EJ3/login").permitAll()
                .antMatchers(HttpMethod.GET, "/EJ3/persona/all").hasAnyRole("USER", "ADMIN")
                .antMatchers(HttpMethod.POST, "EJ3/persona").hasAnyRole( "USER")
                .antMatchers(HttpMethod.PUT, "EJ3/persona/{id}").hasAnyRole( "ADMIN")
                .antMatchers(HttpMethod.DELETE, "EJ3/persona/{id}").hasAnyRole( "ADMIN")
                .anyRequest().authenticated();
    }

}