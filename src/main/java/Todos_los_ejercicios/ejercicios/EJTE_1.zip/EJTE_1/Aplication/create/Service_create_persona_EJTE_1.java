package Todos_los_ejercicios.ejercicios.EJTE_1.Aplication.create;

import Todos_los_ejercicios.ejercicios.EJTE_1.Domain.Persona_EJTE_1;

public interface Service_create_persona_EJTE_1 {

    Persona_EJTE_1 create_persona(Persona_EJTE_1 persona_EJTE1) throws Exception;

}
