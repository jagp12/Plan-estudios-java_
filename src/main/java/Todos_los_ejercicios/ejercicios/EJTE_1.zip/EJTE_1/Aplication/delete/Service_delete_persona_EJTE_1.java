package Todos_los_ejercicios.ejercicios.EJTE_1.Aplication.delete;

import Todos_los_ejercicios.ejercicios.EJTE_1.Exceptions.Exception_persona_404;

public interface Service_delete_persona_EJTE_1 {

    void delete_by_id(String id) throws Exception_persona_404;

}
